/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packageCitasM;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Administrator
 */
@WebService(serviceName = "BuscarCitasM")
public class BuscarCitasM {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "consultar")
    public String consultar(){
 String cita="";
    try{
    ConexionDB con = new ConexionDB();
    con.conectar();
    String consulta="select * from tbcitas";
    con.resultado= con.query.executeQuery(consulta);
    
    while(con.resultado.next()){
    
        cita=cita+" "+con.resultado.getString("Numerocita")+" "+con.resultado.getString("IdentificacionPaciente")+" "+con.resultado.getString("NombreMedico")+" "+con.resultado.getString("EspecialidadMedico")+" "+con.resultado.getString("DiaCita")+" "+con.resultado.getString("Hora")+"\n";
        
    }

     con.desconectar();
    }
    catch(Exception e){
       
    }
    
return cita;
}
}
