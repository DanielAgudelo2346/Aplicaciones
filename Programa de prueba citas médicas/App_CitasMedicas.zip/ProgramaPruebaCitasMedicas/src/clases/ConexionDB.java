/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
/**
 *
 * @author alejandro
 */
public class ConexionDB {
    public Connection conexion;
    public Statement query;
    public ResultSet resultado;
    
    public void conectar(){
        try{
            final String Controlador ="com.mysql.jdbc.Driver";
            Class.forName(Controlador);
            final String urldb= "jdbc:mysql://localhost:3306/programaprueba";
            conexion = DriverManager.getConnection(urldb,"root","");
            query= conexion.createStatement();
        }
        catch(ClassNotFoundException | SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage(), "error", JOptionPane.ERROR_MESSAGE);
            
        }
    }
    public void desconectar(){
        try{
            if(conexion != null){
                if (query !=null ){
                    query.close();
                }
                conexion.close();
            }
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage(),"error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }
    public Connection getconexion(){
        return conexion;
    }
}
