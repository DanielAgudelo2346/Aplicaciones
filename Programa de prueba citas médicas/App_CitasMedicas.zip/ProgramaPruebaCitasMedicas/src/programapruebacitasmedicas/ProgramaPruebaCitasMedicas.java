/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programapruebacitasmedicas;

import Formularios.Index;
import java.awt.Color;

/**
 *
 * @author Administrator
 */
public class ProgramaPruebaCitasMedicas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Index i =new Index();
                i.getContentPane().setBackground( Color.decode("#EEF6F9") );

        i.setVisible(true);
    }
    
}
